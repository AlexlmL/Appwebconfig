namespace ACME.LearningCenterPlatform.API.Profiles.Interfaces.REST.Resources;

public record ProfileResource(int Id, string FullName, string Email, string StreetAddress);