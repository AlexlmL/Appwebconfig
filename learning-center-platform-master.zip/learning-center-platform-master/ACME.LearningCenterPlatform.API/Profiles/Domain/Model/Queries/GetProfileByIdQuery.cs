namespace ACME.LearningCenterPlatform.API.Profiles.Domain.Model.Queries;

public record GetProfileByIdQuery(int ProfileId);