namespace ACME.LearningCenterPlatform.API.Publishing.Interfaces.REST.Resources;

public record CategoryResource(int Id, string Name);