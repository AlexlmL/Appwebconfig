namespace ACME.LearningCenterPlatform.API.Publishing.Interfaces.REST.Resources;

public record AddVideoAssetToTutorialResource(string VideoUrl);