namespace ACME.LearningCenterPlatform.API.Publishing.Interfaces.REST.Resources;

public record CreateCategoryResource(string Name);