namespace ACME.LearningCenterPlatform.API.Publishing.Domain.Model.Commands;

public record CreateCategoryCommand(string Name);