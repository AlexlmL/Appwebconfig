namespace ACME.LearningCenterPlatform.API.Publishing.Domain.Model.Queries;

public record GetTutorialByIdQuery(int TutorialId);