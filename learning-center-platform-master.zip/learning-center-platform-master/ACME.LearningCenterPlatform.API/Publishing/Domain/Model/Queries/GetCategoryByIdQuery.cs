namespace ACME.LearningCenterPlatform.API.Publishing.Domain.Model.Queries;

public record GetCategoryByIdQuery(int CategoryId);