namespace ACME.LearningCenterPlatform.API.Publishing.Domain.Model.ValueObjects;

public record ContentItem(string Type, string Content);