namespace ACME.LearningCenterPlatform.API.Publishing.Domain.Model.ValueObjects;

public record ProfileId(int Id);