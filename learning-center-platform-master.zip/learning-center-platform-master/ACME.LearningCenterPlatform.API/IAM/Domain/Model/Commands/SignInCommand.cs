namespace ACME.LearningCenterPlatform.API.IAM.Domain.Model.Commands;

public record SignInCommand(string Username, string Password);