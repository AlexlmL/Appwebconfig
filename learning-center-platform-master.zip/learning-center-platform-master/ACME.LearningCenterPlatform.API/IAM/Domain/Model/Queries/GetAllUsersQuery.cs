namespace ACME.LearningCenterPlatform.API.IAM.Domain.Model.Queries;

public record GetAllUsersQuery();