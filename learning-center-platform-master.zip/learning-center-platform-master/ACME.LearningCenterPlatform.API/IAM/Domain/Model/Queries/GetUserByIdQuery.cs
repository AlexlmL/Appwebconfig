namespace ACME.LearningCenterPlatform.API.IAM.Domain.Model.Queries;

public record GetUserByIdQuery(int Id);