namespace ACME.LearningCenterPlatform.API.IAM.Interfaces.REST.Resources;

public record UserResource(int Id, string Username);
