namespace ACME.LearningCenterPlatform.API.IAM.Interfaces.REST.Resources;

public record SignUpResource(string Username, string Password);