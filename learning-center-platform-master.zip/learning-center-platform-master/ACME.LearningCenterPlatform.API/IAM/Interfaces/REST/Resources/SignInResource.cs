namespace ACME.LearningCenterPlatform.API.IAM.Interfaces.REST.Resources;

public record SignInResource(string Username, string Password);